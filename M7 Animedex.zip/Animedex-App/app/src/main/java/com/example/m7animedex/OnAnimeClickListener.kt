package com.example.m7animedex

import com.example.m7animedex.data.model.Anime

interface OnAnimeClickListener {
    fun onAnimeClick(anime: Anime)
}